def spiral(n):
    result = ''
    direction = 0 # 0 for right, 1 for down, 2 for left, 3 for up
    count = 0

    for layer in range(n):
        for step in range(layer*2 + 1):
            if step == layer:
                if direction == 0:
                    result += '*'
                elif direction == 1:
                    result += '**'
                elif direction == 2:
                    result += '***'
                elif direction == 3:
                    result += '****'
                count += 1
            elif count == 4:
                direction = (direction + 1) % 4
                count = 0

            result += ' '

        result += '\n'

    return result

n = int(input("Ingrese el tamaño del espiral: "))
print(spiral(n))